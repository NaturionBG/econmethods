from econmethods import CipsTest

__all__ = ['CipsTest']